package service;

import dao.IDao;
import model.Paciente;

public class PacienteService {
    private IDao<Paciente> pacienteDao;

    public PacienteService(IDao<Paciente> pacienteDao) {
        this.pacienteDao = pacienteDao;
    }

    public Paciente buscarPaciente(int id){
        return pacienteDao.buscar(id);
    }

    public Paciente guardarPaciente(Paciente paciente){
        return pacienteDao.guardar(paciente);
    }

}
