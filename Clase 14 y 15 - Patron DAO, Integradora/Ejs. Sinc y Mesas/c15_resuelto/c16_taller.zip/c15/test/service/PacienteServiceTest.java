package service;

import dao.PacienteDAOH2;
import model.Domicilio;
import model.Paciente;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class PacienteServiceTest {
    @Test
    public void agregarYBuscarPacienteTest(){
        //es crear la BD
        Connection connection=null;
        try{
            Class.forName("org.h2.Driver");
            connection= DriverManager.getConnection("jdbc:h2:~/cam94clase15;INIT=RUNSCRIPT " +
                    "FROM 'create.sql'","sa","sa");
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            try{
                connection.close();
            }
            catch (Exception ex){
                ex.printStackTrace();
            }
        }
        //preparar el domicilio y el paciente
        Domicilio domicilioParaAgregar= new Domicilio("Calle C",584,"Salta",
                "Salta");
        Paciente pacienteParaAgregar=new Paciente("Pedro",584,
                LocalDate.of(2022,05,31), domicilioParaAgregar);
        PacienteService pacienteService= new PacienteService(new PacienteDAOH2());

        //guardar el paciente y buscarlo
        pacienteService.guardarPaciente(pacienteParaAgregar);
        Paciente pacienteResultado=pacienteService.buscarPaciente(3);

        assertEquals(pacienteParaAgregar.getDni(),pacienteResultado.getDni());
    }
}