package com.dh.clase39;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase39Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase39Application.class, args);
	}

}
