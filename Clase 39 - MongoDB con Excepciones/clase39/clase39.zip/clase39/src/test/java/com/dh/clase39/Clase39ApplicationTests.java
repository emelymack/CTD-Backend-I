package com.dh.clase39;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase39ApplicationTests {

	@Test
	void contextLoads() {
	}

}
