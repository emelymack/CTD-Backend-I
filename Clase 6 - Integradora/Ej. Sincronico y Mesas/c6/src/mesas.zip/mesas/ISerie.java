package mesas;

public interface ISerie {
    String getSerie(Serie nombreSerie) throws SerieNoHabilitadaException;
}
