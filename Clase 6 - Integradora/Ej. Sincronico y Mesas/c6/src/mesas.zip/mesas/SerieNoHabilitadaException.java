package mesas;

public class SerieNoHabilitadaException extends Exception{
    public SerieNoHabilitadaException(String msjError){
        super(msjError);
    }
}
